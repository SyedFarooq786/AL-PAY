// backend/routes/auth.js

const express = require('express');
const router = express.Router();
const User = require('../models/User');

// POST /api/auth/save-user-details
router.post('/save-user-details', async (req, res) => {
  const { phoneNumber, callingCode, firstName, lastName, currencyCode } = req.body;

  try {
    // Check if user already exists based on phoneNumber
    const existingUser = await User.findOne({ phoneNumber });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists with this phone number.' });
    }

    // Create a new user instance
    const newUser = new User({
      phoneNumber,
      callingCode,
      firstName,
      lastName,
      currencyCode
    });

    // Save the user to MongoDB
    await newUser.save();

    res.status(201).json(newUser); // Respond with the newly created user
  } catch (error) {
    console.error('Error saving user:', error);
    res.status(500).json({ error: 'Server error. Failed to save user.' });
  }
});

module.exports = router;
